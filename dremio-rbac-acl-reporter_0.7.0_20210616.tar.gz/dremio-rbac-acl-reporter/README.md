# dremio-rbac-acl-reporter
The Dremio RBAC Upgrade ACL Reporter tool, known as dremio_rbac_acl_reporter, enables administrators to report on and make comparisons between the access control lists (ACLs) for all objects in Dremio before and after an upgrade to a Dremio version that contains the new RBAC model. 
The tool makes it easy to reconcile what privileges a user or group had on a dataset before the upgrade with what privileges the same user or group has on a dataset after the upgrade. This will help Dremio Professional Services and Customer Success Managers to explain the differences that customers are seeing and to pinpoint any specific anomalies that a customer may want to investigate in more detail.

The tool does not make any changes to the Dremio environment, nor does it make any recommendations, it is purely used for reading data and generating a report. 

The tool is intended to be executed once before the upgrade, which will generate a json file and a csv file as output. The json file is not intended to be read directly, it is just an intermediate file storing the ACL information obtained prior to the upgrade. The csv file contains a summary of the ACLs against each resource and the effective access this grants a specific user/group to the resource.

In addition, the tool is intended to be executed once after the upgrade after Dremio has been restarted. The post-upgrade execution requires the json file generated from the pre-upgrade execution be used as an input, this is because the tool will automatically reconcile the two sets of ACLs into a single resulting csv file and it will flag where there are differences in a user/role access privileges for each dataset. A json file containing both sets of ACLs is also generated, but this can be ignored.

Further details can be found in docs/Dremio RBAC Upgrade ACL Reporter - User Guide.docx

## Pre-Upgrade Usage Example
python dremio_rbac_acl_reporter.py --url http(s)://localhost:9047 --user dremio_admin_user --output-json-file pre-rbac-acls.json --output-csv-file pre-rbac-acls.csv --source-include-filter "source1,source 2"

## Post-Upgrade Usage Example
python dremio_rbac_acl_reporter.py --url http(s)://localhost:9047 --user dremio_admin_user --pre-rbac-acls-to-compare pre-rbac-acls.json --output-json-file rbac-acls.json --output-csv-file rbac-acl-comparison.csv

Note: If --password is omitted from the above commands then you will be prompted to enter the password for the Dremio admin user on the command line.