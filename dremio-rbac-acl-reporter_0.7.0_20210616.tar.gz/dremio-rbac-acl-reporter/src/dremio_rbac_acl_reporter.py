#!/usr/bin/python
import requests
import copy
import sys
import time
import argparse
import json
import getpass
import logging
from six.moves.urllib.parse import quote

delimiter = ','
new_line = '\n'
publicAcl = {"groups": [{"id": "PUBLIC","permissions": ["READ","WRITE"]}]}


def login(url, user, password, tls_verify):
    """ Login to Dremio
    Args:
        url:        Dremio URL
        user:       user to authenticate with
        password:   user password
        tls_verify: flag to state if tls should be verified
    Returns
        Authentication string
    """
    login_path = '/apiv2/login'
    logging.info("Logging in as {}".format(user))
    login_data = {"userName": user, "password": password}
    response = requests.post(url+login_path, json=login_data, verify=tls_verify, timeout=30)
    if response.status_code != 200:
        sys.exit('Login failure, Status code : {}'.format(response.status_code))
    else:
        logging.info("Login successful")
        j = json.loads(response.text)
        return '_dremio'+j['token']


# Returns Job ID or None
def submit_sql(url, auth_string, sql, tls_verify, context=None):
    job = requests.post(url + "/api/v3/sql", headers={'Authorization': auth_string}, verify=tls_verify,
                        json={"sql": sql, "context": context})
    if job is not None and job.status_code != 200:
        logger.error('Query failure, Status code : {}'.format(job.status_code))
        return None
    return job.json()["id"]


def get_job_status(url, auth_string, queryId, tls_verify):
    job_status_path = '/api/v3/job/' + queryId
    response = requests.get(url+job_status_path, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        return None
    else:
        return response.json()


def get_job_results(url, auth_string, job_id, tls_verify=True, offset=0, limit=100):
    resp = requests.get(
        url + "/api/v3/job/{}/results?offset={}&limit={}".format(job_id, offset, limit),
        headers={'Authorization': auth_string}, verify=tls_verify)
    return resp.json()


def get_catalog(url, auth_string, tls_verify):
    """ Get root catalog
    Args:
        url:        Dremio URL
        auth_string: authentication token
        tls_verify: flag to state if tls should be verified
    Returns
        Dremio entity object in JSON format
    """
    catalog_path = '/api/v3/catalog'
    response = requests.get(url+catalog_path, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        logger.error('Failed to get catalog, Status code : {}'.format(str(response.status_code)))
        return None
    else:
        return response.json()


def get_catalog_by_path(url, auth_string, path, tls_verify, report_error=True):
    """ Get entity by path from Dremio catalog
    Args:
        url:        Dremio URL
        aut_string: authentication token
        path:         path of entity to retrive
        tls_verify: flag to state if tls should be verified
    Returns
        Dremio entity object in JSON format
    """
    catalog_path = '/api/v3/catalog'
    cpath = [quote(i, safe="") for i in path] if path else ""
    endpoint = "/by-path/{}".format("/".join(cpath).replace('"', ""))
    response = requests.get(url+catalog_path+endpoint, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        if report_error:
            logging.warning('Failed to get entity {}, Status code : {}. Response: {}'.format("/".join(cpath), str(response.status_code), response.text))
        return None
    else:
        return response.json()


def get_catalog_entity_by_path(url, auth_string, path_string, tls_verify, report_error=True):
    """ Get entity by path from Dremio catalog
    Args:
        url:        Dremio URL
        aut_string: authentication token
        path:         path of entity to retrive
        tls_verify: flag to state if tls should be verified
    Returns
        Dremio entity object in JSON format
    """
    catalog_path = '/api/v3/catalog/by-path/'
    response = requests.get(url+catalog_path+path_string, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        if report_error:
            logging.warning('Failed to get entity {}, Status code : {}. Response: {}'.format(path_string, str(response.status_code), response.text))
        return None
    else:
        return response.json()


def get_role_by_id(url, auth_string, role_id, tls_verify, report_error=True):
    """ Get role by id from Dremio
    Args:
        url:        Dremio URL
        auth_string: authentication token
        role_id:   id of role to retrieve
        tls_verify: flag to state if tls should be verified
    Returns
        Dremio role object in JSON format
    """
    api_path = '/api/v3/role/'
    response = requests.get(url+api_path+role_id, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        if report_error:
            logging.warning('Failed to get role for role id {}, Status code : {}'.format(role_id, str(response.status_code)))
        return None
    else:
        return response.json()


def get_user_by_id(url, auth_string, user_id, tls_verify, report_error=True):
    """ Get user by id from Dremio
    Args:
        url:        Dremio URL
        auth_string: authentication token
        user_id:   id of user to retrieve
        tls_verify: flag to state if tls should be verified
    Returns
        Dremio user object in JSON format
    """
    api_path = '/api/v3/user/'
    response = requests.get(url+api_path+user_id, headers={'Authorization': auth_string}, verify=tls_verify)
    if response.status_code != 200:
        if report_error:
            logging.warning('Failed to get details for user id {}, Status code : {}'.format(user_id, str(response.status_code)))
        return None
    else:
        return response.json()


def parent_acl_contains_read(child_id, parent_acls):
    for parent_acl in parent_acls:
        if parent_acl['id'] == child_id:
            if 'effectivePermissions' in parent_acl:
                if 'READ' in parent_acl['effectivePermissions']:
                    return True
            elif 'READ' in parent_acl['permissions']:
                return True
    return False


def update_effective_acls(child_acls, parent_acls, parent_acl_is_public):
    child_users = []
    child_groups = []
    parent_users = []
    parent_groups = []

    # users
    if 'users' in child_acls:
        child_users = child_acls['users']
    if 'users' in parent_acls:
        parent_users = parent_acls['users']
    # groups
    if 'groups' in child_acls:
        child_groups = child_acls['groups']
    if 'groups' in parent_acls:
        parent_groups = parent_acls['groups']

    for child_user in child_users:
        if parent_acl_is_public or parent_acl_contains_read(child_user['id'], parent_users):
            child_user['effectivePermissions'] = child_user['permissions']
            child_user['effectivePermissionsReason'] = 'User can traverse to this entity'
        else:
            child_user['effectivePermissions'] = []
            child_user['effectivePermissionsReason'] = 'User CANNOT traverse to this entity. Missing READ in parent hierarchy'

    for child_group in child_groups:
        if parent_acl_is_public or parent_acl_contains_read(child_group['id'], parent_groups):
            child_group['effectivePermissions'] = child_group['permissions']
            child_group['effectivePermissionsReason'] = 'Group can traverse to this entity'
        else:
            child_group['effectivePermissions'] = []
            child_group['effectivePermissionsReason'] = 'Group CANNOT traverse to this entity. Missing READ in parent hierarchy'


def update_rbac_effective_acls(dataset_acls, inherited_acls):
    if dataset_acls == {}:
        dataset_acls = copy.deepcopy(inherited_acls)
        if 'users' in dataset_acls:
            for dataset_user in dataset_acls['users']:
                dataset_user['effectivePermissions'] = dataset_user['permissions']
                dataset_user['permissions'] = []
                if 'MODIFY' in dataset_user['effectivePermissions']:
                    dataset_user['effectivePermissions'].remove('MODIFY')
        if 'roles' in dataset_acls:
            for dataset_role in dataset_acls['roles']:
                dataset_role['effectivePermissions'] = dataset_role['permissions']
                dataset_role['permissions'] = []
                if 'MODIFY' in dataset_role['effectivePermissions']:
                    dataset_role['effectivePermissions'].remove('MODIFY')
    else:
        if 'users' in dataset_acls:
            for dataset_user in dataset_acls['users']:
                dataset_user['effectivePermissions'] = dataset_user['permissions']
                if 'MODIFY' in dataset_user['effectivePermissions']:
                    dataset_user['effectivePermissions'].remove('MODIFY')
        if 'roles' in dataset_acls:
            for dataset_role in dataset_acls['roles']:
                dataset_role['effectivePermissions'] = dataset_role['permissions']
                if 'MODIFY' in dataset_role['effectivePermissions']:
                    dataset_role['effectivePermissions'].remove('MODIFY')
    return dataset_acls


def recurse_children_non_rbac(url, auth_string, children, parent_acls, parent_acl_is_public, tls_verify):
    child_entities = []
    entity_wanted_keys = ['id', 'entityType', 'path', 'accessControlList']
    for child in children:
        if 'path' in child:
            child_entity = get_catalog_by_path(url, auth_string, child['path'], tls_verify)
            if child_entity is not None:
                child_acl_is_public = False
                logging.info('Processing {}: {}'.format(child_entity['entityType'], "/".join(child['path'])))
                if 'accessControlList' not in child_entity:
                    child_entity['accessControlList'] = copy.deepcopy(parent_acls)
                    child_acl_is_public = parent_acl_is_public
                if 'version' in child_entity['accessControlList']:
                    del child_entity['accessControlList']['version']
                if child_entity['accessControlList'] == {}:
                    child_entity['accessControlList'] = copy.deepcopy(parent_acls)
                    child_acl_is_public = parent_acl_is_public
                update_effective_acls(child_entity['accessControlList'], parent_acls, parent_acl_is_public)
                entity = dict((k, child_entity[k]) for k in entity_wanted_keys)
                if 'children' in child_entity:
                    entity['children'] = recurse_children_non_rbac(url, auth_string, child_entity['children'], entity['accessControlList'], child_acl_is_public, tls_verify)
                child_entities.append(entity)
    return child_entities


def generate_table_schema_filter(source_name):
    if source_include_filter_list == []:
        return " AND TABLE_SCHEMA = '" + source_name + "' OR TABLE_SCHEMA like '" + source_name + ".%'"

    table_schema_filter = ''
    for filter_item in source_include_filter_list:
        if filter_item.split('/')[0] == source_name:
            table_schema_filter_value = filter_item.replace('/', '.')
            table_schema_filter = (table_schema_filter + " OR ") if table_schema_filter != '' else (table_schema_filter + " AND ")
            table_schema_filter = table_schema_filter + "TABLE_SCHEMA = '" + table_schema_filter_value + "' OR TABLE_SCHEMA like '" + table_schema_filter_value + ".%'"
    return table_schema_filter


def read_all_pds_for_source(url, auth_string, source_name, source_acls, source_acl_is_public, tls_verify):
    pds_list = []
    cached_schemas = {}
    entity_wanted_keys = ['id', 'entityType', 'path', 'accessControlList']
    table_schema_filter = generate_table_schema_filter(source_name)
    # Retrieve PDS list from Dremio meta-schema
    sql = " SELECT TABLE_SCHEMA, TABLE_NAME FROM \"INFORMATION_SCHEMA\".\"TABLES\" WHERE TABLE_TYPE = 'TABLE' "
    sql = sql + table_schema_filter

    jobid = submit_sql(url, auth_string, sql, tls_verify)
    # Wait for the job to complete. Should only take a moment
    while True:
        job_info = get_job_status(url, auth_string, jobid, tls_verify)
        if job_info is None:
            logging.error("read_all_pds_for_source: unexpected error. Cannot get a list of PDS.")
            raise RuntimeError("Unexpected error. Cannot get a list of PDS.")
        if job_info["jobState"] in ['CANCELED', 'FAILED']:
            logging.error("read_all_pds_for_source: unexpected error, SQL job failed. Cannot get a list of PDS.")
            raise RuntimeError("Unexpected error, SQL job failed. Cannot get a list of PDS.")
        if job_info["jobState"] == 'COMPLETED':
            break
        time.sleep(1)
    # Retrieve list of PDS
    job_result = get_job_results(url, auth_string, jobid, tls_verify)
    num_rows = int(job_result['rowCount'])
    if num_rows == 0:
        return pds_list
    # Page through the results, 100 rows per page
    limit = 100
    for i in range(0, int(num_rows / limit) + 1):
        job_result = get_job_results(url, auth_string, jobid, tls_verify, limit * i, limit)
        for row in job_result['rows']:
            # The schema (path) is denormalized: instead of abc/ab.c/abc it has abc.ab.c.abc, we need to recover it
            normalized_path = normalize_schema(url, auth_string, row['TABLE_SCHEMA'], cached_schemas)
            try:
                logging.info("Processing PDS: {}".format(normalized_path + row['TABLE_NAME']))
                entity = get_catalog_entity_by_path(url, auth_string, normalized_path + row['TABLE_NAME'], tls_verify)
                if entity is not None:
                    entity = dict((k, entity[k]) for k in entity_wanted_keys)
                    if 'version' in entity['accessControlList']:
                        del entity['accessControlList']['version']
                    if entity['accessControlList'] == {}:
                        entity['accessControlList'] = copy.deepcopy(source_acls)
                    update_effective_acls(entity['accessControlList'], source_acls, source_acl_is_public)
                    pds_list.append(entity)
            except:
                logging.warning("Skipping PDS")
    return pds_list


def normalize_schema(url, auth_string, schema, cached_schemas):
    if schema in cached_schemas:
        return cached_schemas[schema]
    path = schema.split('.')
    normalized_path = ""
    for i in range(0, len(path)):
        normalized_path = normalized_path + path[i]
        entity = get_catalog_entity_by_path(url, auth_string, normalized_path, tls_verify, report_error=False)
        if entity is not None:
            normalized_path = normalized_path + '/'
        else:
            normalized_path = normalized_path + '.'
    cached_schemas[schema] = normalized_path
    return normalized_path


def recurse_update_acl_entity(url, auth_string, acl_entity, parent_acls, tls_verify):
    inherited_acls = {}
    logging.info("Processing {}: {}".format(acl_entity['entityType'], "/".join(acl_entity['path'])))
    dremio_entity = get_catalog_by_path(url, auth_string, acl_entity['path'], tls_verify)
    acl_entity['accessControlListRBAC'] = dremio_entity['accessControlList']
    if acl_entity['accessControlListRBAC'] == {} and parent_acls:
        inherited_acls = copy.deepcopy(parent_acls)
    else:
        # append current entity's acls to parent acls to generate superset of inherited acls
        inherited_acls = copy.deepcopy(acl_entity['accessControlListRBAC'])
        # only take acl from parent if it's not already in inherited_acls via current entity
        if parent_acls:
            for user in (parent_acls['users'] if 'users' in parent_acls else []):
                if not any(user['id'] in sl for sl in (inherited_acls['users'] if 'users' in inherited_acls else [])):
                    if 'users' in inherited_acls:
                        inherited_acls['users'].append(user)
                    else:
                        inherited_acls['users'] = [user]
            for role in (parent_acls['roles'] if 'roles' in parent_acls else []):
                if not any(role['id'] in sl for sl in (inherited_acls['roles'] if 'roles' in inherited_acls else [])):
                    if 'roles' in inherited_acls:
                        inherited_acls['roles'].append(role)
                    else:
                        inherited_acls['roles'] = [role]

    if 'version' in acl_entity['accessControlListRBAC']:
        del acl_entity['accessControlListRBAC']['version']
    if 'dataset' in acl_entity['entityType']:
        acl_entity['accessControlListRBAC'] = update_rbac_effective_acls(acl_entity['accessControlListRBAC'], inherited_acls)
    if 'children' in acl_entity:
        for child_entity in acl_entity['children']:
            recurse_update_acl_entity(url, auth_string, child_entity, inherited_acls, tls_verify)


def recurse_write_pre_rbac_acl_entity_to_csv(url, auth_string, acl_entity, output_csv_file, user_names, tls_verify):
    users = []
    groups = []

    # users
    if 'accessControlList' in acl_entity and 'users' in acl_entity['accessControlList']:
        users = acl_entity['accessControlList']['users']
    #groups
    if 'accessControlList' in acl_entity and 'groups' in acl_entity['accessControlList']:
        groups = acl_entity['accessControlList']['groups']

    logging.info("Writing {}: {}".format(acl_entity['entityType'], "/".join(acl_entity['path'])))
    # Iterate over and output each user acl
    for user in users:
        # output the name of the user rather than the id in the csv file
        if user['id'] not in user_names:
            dremio_user = get_user_by_id(url, auth_string, user['id'], tls_verify)
            if dremio_user and 'name' in dremio_user:
                user_names[user['id']] = dremio_user['name']
            else:  # couldn't find the user in Dremio
                user_names[user['id']] = user['id']
        output_csv_file.write(acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                acl_entity['path']) + delimiter + user_names[user['id']] + delimiter + 'user' + delimiter + "/".join(
                sorted(user['permissions'])) + delimiter + "/".join(sorted(user['effectivePermissions'])) + delimiter +
                user['effectivePermissionsReason'] + new_line)

    # Iterate over and output each group acl
    for group in groups:
        output_csv_file.write(
            acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                acl_entity['path']) + delimiter + group['id'] + delimiter + 'group' + delimiter + "/".join(
                sorted(group['permissions'])) + delimiter + "/".join(sorted(group['effectivePermissions'])) + delimiter +
            group['effectivePermissionsReason'] + new_line)

    if 'children' in acl_entity:
        for child_entity in acl_entity['children']:
            recurse_write_pre_rbac_acl_entity_to_csv(url, auth_string, child_entity, output_csv_file, user_names, tls_verify)


def is_acl_match(root_acl_entity_type, pre_rbac_effective_acls, rbac_acls):
    temp_pre_acls = []
    # check if both lists are empty
    if not pre_rbac_effective_acls and not rbac_acls:
        return True
    if 'READ' in pre_rbac_effective_acls:
        # READ on a source in pre-RBAC maps to SELECT/ALTER/MANAGE_GRANTS in RBAC
        if root_acl_entity_type == 'source' and 'SELECT' in rbac_acls and 'ALTER' in rbac_acls and 'MANAGE_GRANTS' in rbac_acls:
            return True
        temp_pre_acls.append('SELECT')
    if 'WRITE' in pre_rbac_effective_acls:
        temp_pre_acls.append('ALTER')
        temp_pre_acls.append('MANAGE_GRANTS')
    return sorted(temp_pre_acls) == sorted(rbac_acls)


def recurse_write_comparison_to_csv(url, auth_string, acl_entity, root_acl_entity_type, output_csv_file, user_names, rbac_role_names, tls_verify):
    users = []
    rbac_users = []
    groups = []
    rbac_roles = []

    # users
    if 'accessControlList' in acl_entity and 'users' in acl_entity['accessControlList']:
        users = acl_entity['accessControlList']['users']
    if 'accessControlListRBAC' in acl_entity and 'users' in acl_entity['accessControlListRBAC']:
        rbac_users = copy.deepcopy(acl_entity['accessControlListRBAC']['users'])
    #groups/roles
    if 'accessControlList' in acl_entity and 'groups' in acl_entity['accessControlList']:
        groups = acl_entity['accessControlList']['groups']
    if 'accessControlListRBAC' in acl_entity and 'roles' in acl_entity['accessControlListRBAC']:
        rbac_roles = copy.deepcopy(acl_entity['accessControlListRBAC']['roles'])

    logging.info("Writing {}: {}".format(acl_entity['entityType'], "/".join(acl_entity['path'])))
    # Iterate over each user acl, match pre-rbac to post-rbac acls and output matches on the same row
    for user in users:
        # output the name of the user rather than the id in the csv file
        if user['id'] not in user_names:
            dremio_user = get_user_by_id(url, auth_string, user['id'], tls_verify)
            if dremio_user and 'name' in dremio_user:
                user_names[user['id']] = dremio_user['name']
            else:  # couldn't find the user in Dremio
                user_names[user['id']] = user['id']
        user_found = False
        for rbac_user in rbac_users:
            # output acls for users that are in both lists
            if user['id'] == rbac_user['id']:
                user_found = True
                acl_match = is_acl_match(root_acl_entity_type, user['effectivePermissions'], rbac_user['effectivePermissions'] if 'effectivePermissions' in rbac_user else rbac_user['permissions'])
                output_csv_file.write(acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                        acl_entity['path']) + delimiter + user_names[user['id']] + delimiter + 'user' + delimiter + "/".join(
                        sorted(user['effectivePermissions'])) + delimiter + 'user' + delimiter + "/".join(
                        sorted(rbac_user['permissions'])) + delimiter +
                        ("/".join(sorted(rbac_user['effectivePermissions'])) if 'effectivePermissions' in rbac_user else '') +
                        delimiter + (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)
                rbac_users.remove(rbac_user)
        # output acls for users that are in the users list but not in rbac_users
        if not user_found:
            acl_match = is_acl_match(root_acl_entity_type, user['effectivePermissions'], [])
            output_csv_file.write(
                acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                    acl_entity['path']) + delimiter + user_names[user['id']] + delimiter + 'user' + delimiter + "/".join(
                    sorted(user['effectivePermissions'])) + delimiter + '' + delimiter + '' + delimiter + '' + delimiter +
                    (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)
    # output users that are in rbac_users but not in users - shouldn't happen
    for rbac_user in rbac_users:
        acl_match = is_acl_match(root_acl_entity_type, [], rbac_user['effectivePermissions'] if 'effectivePermissions' in rbac_user else rbac_user['permissions'])
        output_csv_file.write(
            acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                acl_entity['path']) + delimiter + rbac_user['id'] + delimiter + '' + delimiter + '' + delimiter + 'user' + delimiter + "/".join(
                sorted(rbac_user['permissions'])) + delimiter +
            ("/".join(sorted(rbac_user['effectivePermissions'])) if 'effectivePermissions' in rbac_user else '') +
            delimiter + (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)

    # Iterate over each group/role acl, match pre-rbac to post-rbac acls and output matches on the same row
    for group in groups:
        role_found = False
        for rbac_role in rbac_roles:
            if rbac_role['id'] not in rbac_role_names:
                dremio_role = get_role_by_id(url, auth_string, rbac_role['id'], tls_verify)
                if dremio_role and 'name' in dremio_role:
                    rbac_role_names[rbac_role['id']] = dremio_role['name']
                else: # can't find role name so use role id instead
                    rbac_role_names[rbac_role['id']] = rbac_role['id']
            # output acls for groups that are in both lists
            if group['id'] == rbac_role_names[rbac_role['id']]:
                role_found = True
                acl_match = is_acl_match(root_acl_entity_type, group['effectivePermissions'], rbac_role['effectivePermissions'] if 'effectivePermissions' in rbac_role else rbac_role['permissions'])
                output_csv_file.write(
                    acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                        acl_entity['path']) + delimiter + group['id'] + delimiter + 'group' + delimiter + "/".join(
                        sorted(group['effectivePermissions'])) + delimiter + 'role' + delimiter + "/".join(
                        sorted(rbac_role['permissions'])) + delimiter +
                    ("/".join(sorted(rbac_role['effectivePermissions'])) if 'effectivePermissions' in rbac_role else '') +
                    delimiter + (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)
                rbac_roles.remove(rbac_role)
        # output acls for groups that are in the groups list but not in rbac_roles list
        if not role_found:
            acl_match = is_acl_match(root_acl_entity_type, group['effectivePermissions'], [])
            output_csv_file.write(
                acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                    acl_entity['path']) + delimiter + group['id'] + delimiter + 'group' + delimiter + "/".join(
                    sorted(group['effectivePermissions'])) + delimiter + '' + delimiter + '' + delimiter + '' + delimiter +
                (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)
    # output users that are in rbac_roles but not in groups
    for rbac_role in rbac_roles:
        if rbac_role['id'] not in rbac_role_names:
            dremio_role = get_role_by_id(url, auth_string, rbac_role['id'], tls_verify)
            if dremio_role and 'name' in dremio_role:
                rbac_role_names[rbac_role['id']] = dremio_role['name']
            else:  # can't find role name so use role id instead
                rbac_role_names[rbac_role['id']] = rbac_role['id']
        acl_match = is_acl_match(root_acl_entity_type, [], rbac_role['effectivePermissions'] if 'effectivePermissions' in rbac_role else rbac_role['permissions'])
        # filter out PUBLIC role entries for datasets if no ACLs are defined
        if not ('PUBLIC' == rbac_role_names[rbac_role['id']] and rbac_role['permissions'] == [] and acl_entity['entityType'] == 'dataset'):
            output_csv_file.write(
                acl_entity['id'] + delimiter + acl_entity['entityType'] + delimiter + "/".join(
                    acl_entity['path']) + delimiter + rbac_role_names[rbac_role['id']] + delimiter + '' + delimiter + '' + delimiter + 'role' + delimiter + "/".join(
                    sorted(rbac_role['permissions'])) + delimiter +
                ("/".join(sorted(rbac_role['effectivePermissions'])) if 'effectivePermissions' in rbac_role else '') +
                delimiter + (str(acl_match) if acl_entity['entityType'] == 'dataset' else '') + new_line)

    if 'children' in acl_entity:
        for child_entity in acl_entity['children']:
            recurse_write_comparison_to_csv(url, auth_string, child_entity, root_acl_entity_type, output_csv_file, user_names, rbac_role_names, tls_verify)


def source_include_filter_list_contains(source_name):
    for filter_item in source_include_filter_list:
        if filter_item.split('/')[0] == source_name:
            return True
    return False

def main():
    user_names = {}
    rbac_role_names = {}
    logging.basicConfig(format="%(levelname)s:%(asctime)s:%(message)s", level=logging.INFO)
    fh = logging.FileHandler('dremio-acl-reporter.log')
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter("%(levelname)s:%(asctime)s:%(message)s"))
    logging.getLogger().addHandler(fh)

    if not tls_verify:
        requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
    auth_string = login(url, user, password, tls_verify)

    # if no pre-RBAC acls have been provided, assume we're processing pre-RBAC version
    if pre_rbac_acls is None:
        logging.info('Writing pre-RBAC ACLs into ' + output_json_file)
        aclListDict = {'aclList': []}
        aclList = aclListDict['aclList']
        container_wanted_keys = ['id', 'entityType', 'path', 'accessControlList']
        containers = get_catalog(url, auth_string, tls_verify)
        if containers and containers['data']:
            for container in containers['data']:
                # ignore home spaces
                if 'HOME' not in container['containerType']:
                    if 'SPACE' == container['containerType'] or \
                            ('SOURCE' == container['containerType'] and (source_include_filter_list == [] or source_include_filter_list_contains(container['path'][0]))):
                        logging.info('Processing {}: {}'.format('source' if container['containerType'] == "SOURCE" else "space", "/".join(container['path'])))
                        container_entity = get_catalog_by_path(url, auth_string, container['path'], tls_verify)
                        if container_entity is not None:
                            entity_has_public_acl = False
                            container_entity['path'] = [container_entity['name']]
                            entity = dict((k, container_entity[k]) for k in container_wanted_keys)
                            if 'version' in entity['accessControlList']:
                                del entity['accessControlList']['version']
                            if entity['accessControlList'] == {}:
                                entity['accessControlList'] = publicAcl
                                entity_has_public_acl = True
                            if container['containerType'] == "SOURCE":
                                pds_list = read_all_pds_for_source(url, auth_string, container_entity['name'], entity['accessControlList'], entity_has_public_acl, tls_verify)
                                entity['children'] = pds_list
                            else: # it's a space
                                entity['children'] = recurse_children_non_rbac(url, auth_string, container_entity['children'],  entity['accessControlList'], entity_has_public_acl, tls_verify)
                            update_effective_acls(entity['accessControlList'], entity['accessControlList'], entity_has_public_acl)
                            aclList.append(entity)
                    else:
                        logging.info('Skipping source: {}'.format(container['path']))
        if output_csv_file is not None:
            logging.info('Generating CSV for pre-RBAC data into ' + output_csv_file)
            f = open(output_csv_file, "w")
            f.write(
                'id' + delimiter + 'entityType' + delimiter + 'path' + delimiter + 'name' + delimiter + 'acl_type_pre_rbac' + delimiter +
                'actual_acls_pre_rbac' + delimiter + 'effective_acls_pre_rbac' + delimiter + 'effective_acls_reason' + new_line)
            for acl_entity in aclList:
                recurse_write_pre_rbac_acl_entity_to_csv(url, auth_string, acl_entity, f, user_names, tls_verify)
            f.close()
    else: #pre-RBAC acls have been provided, so assume we'll be processing RBAC acls now and appending the RBAC acls to existing objects
        infile = open(pre_rbac_acls, "r", encoding="utf8")
        aclListDict = json.load(infile)
        aclList = aclListDict['aclList']
        logging.info('Writing RBAC ACLs into ' + output_json_file)
        for acl_entity in aclList:
            recurse_update_acl_entity(url, auth_string, acl_entity, None, tls_verify)
        if output_csv_file is not None:
            logging.info('Generating CSV comparison data into ' + output_csv_file)
            f = open(output_csv_file, "w")
            f.write(
                'id' + delimiter + 'entityType' + delimiter + 'path' + delimiter + 'name' + delimiter + 'acl_type_pre_rbac' + delimiter +
                'effective_acls_pre_rbac' + delimiter + 'acl_type_rbac' + delimiter + 'acls_rbac' + delimiter + 'effective_dataset_acls_rbac' + delimiter + 'dataset_acl_expected' + new_line)
            for acl_entity in aclList:
                recurse_write_comparison_to_csv(url, auth_string, acl_entity, acl_entity['entityType'], f, user_names, rbac_role_names, tls_verify)
            f.close()

    with open(output_json_file, 'w') as outfile:
        json.dump(aclListDict, outfile)
    logging.info('Process Completed')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Script to retrieve ACLs for all objects in Dremio')
    parser.add_argument('--url', type=str, help='Dremio url, example: https://localhost:9047', required=True)
    parser.add_argument('--user', type=str, help='Dremio user', required=True)
    parser.add_argument('--password', type=str, help='Dremio user password', required=False)
    parser.add_argument('--pre-rbac-acls-to-compare', type=str, help='JSON file containing pre-RBAC ACLs to compare against. Only used when running against RBAC version.', required=False)
    parser.add_argument('--output-json-file', type=str, help='Output JSON file to generate', required=True)
    parser.add_argument('--output-csv-file', type=str, help='Output CSV file to generate', required=True)
    parser.add_argument('--source-include-filter', type=str, help='Comma-separated list of sources to process', required=False)
    parser.add_argument('--tls-skip-verify', action='store_false')

    args = parser.parse_args()
    url = args.url
    user = args.user
    password = args.password
    pre_rbac_acls = args.pre_rbac_acls_to_compare
    output_json_file = args.output_json_file
    output_csv_file = args.output_csv_file
    source_include_filter_string = args.source_include_filter
    tls_verify = args.tls_skip_verify

    if not password:
        password = getpass.getpass("Enter password:")

    source_include_filter_list = []
    if source_include_filter_string:
        source_include_filter_list = source_include_filter_string.split(',')
    main()
